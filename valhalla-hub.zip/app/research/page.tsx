export default function Research() {
  return (
    <main className="min-h-screen bg-neutral-950 text-neutral-100">
      <div className="max-w-4xl mx-auto p-6">
        <a href="/" className="text-sm text-neutral-400 hover:text-neutral-200">← Zurück zum Hub</a>
        <h1 className="text-2xl font-semibold tracking-tight mt-4">Research Tool</h1>
        <p className="text-neutral-300 mt-2">Platzhalter-Seite. H2H & letzte N kommen als Nächstes.</p>
        <div className="mt-6 p-4 rounded-xl border border-neutral-800 bg-neutral-900/60">
          <p className="text-neutral-400 text-sm">Hinweis: Dieses MVP zeigt nur die Navigation. Daten/Abfragen werden später ergänzt.</p>
        </div>
      </div>
    </main>
  );
}
